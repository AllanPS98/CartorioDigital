/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cliente;

/**
 *
 * @author User
 */
public class Protocolo {
    
    public static int SAIR = 1;
    public static int CADASTRAR_USUARIO = 2;
    public static int LOGIN = 3;
    public static int CADASTRAR_DOCUMENTO = 4;
    public static int TRANSFERIR_DOCUMENTO = 5;
}
