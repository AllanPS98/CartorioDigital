/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servidor;


import java.net.DatagramPacket;

/**
 *
 * @author User
 */
public class ThreadUDP implements Runnable {

    
    private final DatagramPacket receive;
    
    private static Handler han;
    

    ThreadUDP(DatagramPacket receivePacket, Handler han) {
        this.receive = receivePacket;
        
        ThreadUDP.han = han;
    }

    @Override
    public void run() {

        

    }

    


}
