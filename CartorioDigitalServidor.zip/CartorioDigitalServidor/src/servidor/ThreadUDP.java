/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servidor;


import java.io.IOException;
import java.net.DatagramPacket;
import java.net.MulticastSocket;
import java.util.Arrays;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author User
 */
public class ThreadUDP implements Runnable {

    
    private final DatagramPacket receive;
    private MulticastSocket multiSender;
    private MulticastSocket multiReceiver;
    private DatagramPacket send;
    private static Handler han;
    private byte[] buff = new byte[1024];

    ThreadUDP(MulticastSocket multiSender, MulticastSocket multiReceiver, DatagramPacket sendPacket, DatagramPacket receivePacket, Handler han, byte[] buffer) {
        this.multiReceiver = multiReceiver;
        this.multiSender = multiSender;
        this.send = sendPacket;
        this.receive = receivePacket;
        ThreadUDP.han = han;
        this.buff = buffer;
    }
    

    @Override
    public void run() {

        output("alow");
        String msg;
        try {
            msg = (String) input();
            System.out.println("Mensagem = "+ msg);
        } catch (IOException ex) {
            Logger.getLogger(ThreadUDP.class.getName()).log(Level.SEVERE, null, ex);
        }
        

    }
    
    public Object input() throws IOException{
        multiReceiver.receive(receive);
        return new String(buff);
    }
    
    public void output(Object msg){
        try {
            multiSender.send(send);
        } catch (IOException ex) {
            Logger.getLogger(ThreadUDP.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    

    


}
