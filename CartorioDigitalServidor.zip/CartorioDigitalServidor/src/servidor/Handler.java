/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servidor;

import cliente.Cidadao;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.LinkedList;
import java.util.List;

/**
 *
 * @author User
 */
public class Handler {

    public static Handler han;
    public static List<Cidadao> usuarios = new LinkedList<Cidadao>();

    private Handler() {

    }

    public String cadastrarUsuario(String nome, String cpf, String senha) {
        for(int i = 0; i < usuarios.size(); i++){
            if(cpf.equals(usuarios.get(i).getCpf())){
                return "Já existe algum usuário com esse CPF, tente novamente";
            }
        }
        Cidadao cid = new Cidadao(nome, cpf, senha);
        usuarios.add(cid);
        try {
            escreverArquivoSerial("dados\\usuarios", cid);
            return "Usuário cadastrado com sucesso!";
        } catch (IOException ex) {
            return "Erro ao cadastrar usuário";
        }
    }
    
    public void cadastrarDocumento(){
        
    }

    public static Handler getInstance() {
        if (han == null) {
            han = new Handler();
        }
        return han;
    }

    public void escreverArquivoSerial(String nome, Object obj) throws FileNotFoundException, IOException {
        //Classe responsavel por inserir os objetos
        try (FileOutputStream arquivo = new FileOutputStream(nome)) {
            //Grava o objeto cliente no arquivo
            try ( //Classe responsavel por inserir os objetos
                    ObjectOutputStream objGravar = new ObjectOutputStream(arquivo)) {
                //Grava o objeto cliente no arquivo
                objGravar.writeObject(obj);
                objGravar.flush();
            }
            arquivo.flush();
        }
    }

    public void lerArquivoSerial(String nome) throws FileNotFoundException, IOException, ClassNotFoundException {
        Object obj;
        try {
            // Classe responsavel por recuperar os objetos do arquivo
            try (FileInputStream arquivo = new FileInputStream(nome); // Classe responsavel por recuperar os objetos do arquivo
                    ObjectInputStream leitura = new ObjectInputStream(arquivo)) {
                obj = leitura.readObject();
            }
            if (nome.equals("dados\\usuarios")) {
                usuarios = (List<Cidadao>) obj;
            }
        } catch (FileNotFoundException fnfe) {
            System.out.println("Ainda não existe nenhum arquivo com esse caminho => " + nome);
        }

    }
    
}
