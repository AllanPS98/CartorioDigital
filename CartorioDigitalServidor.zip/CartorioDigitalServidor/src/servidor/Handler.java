/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servidor;

/**
 *
 * @author User
 */
public class Handler {
    public static Handler han;
    
    private Handler() {
        
    }
    
    public static Handler getInstance(){
        if(han==null){
            han = new Handler();
        }
        return han;
    }
}
