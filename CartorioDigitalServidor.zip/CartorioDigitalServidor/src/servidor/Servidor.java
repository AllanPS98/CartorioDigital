/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servidor;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.BindException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author allan
 */
public class Servidor {

    private static int PORTA = 12345;
    static Handler han = Handler.getInstance();

    public static void main(String[] args) throws IOException {
        ouvirTCP();
        //ouvirUDP();
    }

    public static void ouvirTCP() throws IOException {
        boolean erro = true;
        while (erro) {
            try {
                ServerSocket servidor = new ServerSocket(PORTA);
                erro = false;
                new Thread() {
                    @Override
                    public void run() {
                        while (true) {
                            System.out.println("Esperando cliente TCP na porta = " + PORTA + "......");
                            Socket cliente;
                            try {
                                cliente = servidor.accept();
                                System.out.println("cliente conectado");
                                ObjectInputStream in = new ObjectInputStream(cliente.getInputStream());
                                ObjectOutputStream out = new ObjectOutputStream(cliente.getOutputStream());
                                ThreadTCP thread = new ThreadTCP(cliente, in, out, han);
                                Thread t = new Thread(thread);
                                t.start();
                            } catch (IOException ex) {
                                
                            }
                        }
                    }
                }.start();
            } catch (BindException be) {
                PORTA++;
            }
        }
        
        //Server thread = new Server(servidor);
        //Thread t = new Thread(thread);
        //t.start
        
        
    }

    public static void ouvirUDP() throws IOException {

        DatagramSocket serverSocket = new DatagramSocket(PORTA);
        byte[] receiveData = new byte[1024];
        new Thread() {
            @Override
            public void run() {
                while (true) {
                    DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);
                    System.out.println("Esperando cliente UDP......");
                    try {
                        serverSocket.receive(receivePacket);
                    } catch (IOException ex) {
                        Logger.getLogger(Servidor.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    //System.out.println("Datagrama UDP [" + numConn + "] recebido...");
                    ThreadUDP thr = new ThreadUDP(receivePacket, han);
                    Thread t = new Thread(thr);
                    t.start();
                }
            }
        }.start();

    }

}
