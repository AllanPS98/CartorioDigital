package servidor;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;

import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInput;
import java.io.ObjectInputStream;
import java.io.ObjectOutput;
import java.io.ObjectOutputStream;
import java.net.Socket;

import java.util.logging.Level;
import java.util.logging.Logger;


/**
 *
 * @author allan
 */
public class ThreadTCP implements Runnable {

    private final Socket cliente;
    private final ObjectInputStream in;
    private final ObjectOutputStream out;
    
    private static Handler han;
    

    ThreadTCP(Socket cliente, ObjectInputStream in, ObjectOutputStream out, Handler han) {
        this.cliente = cliente;
        this.in = in;
        this.out = out;
        ThreadTCP.han = han;
    }

    @Override
    public void run() {

        
        int protocoloAtual;
        while (true) {
        }
    }

    public Object input() throws IOException, ClassNotFoundException {
        
        try {
            
            InputStream tcpInput = new ObjectInputStream(in);
            
            ByteArrayOutputStream bytes = new ByteArrayOutputStream();
            ObjectOutputStream obj = new ObjectOutputStream(bytes);
            
            try {
                
                obj.writeObject(((ObjectInputStream) tcpInput).readObject());
                bytes.toByteArray();
                Object mensagem = desserializarMensagem(bytes.toByteArray());
                System.out.println(mensagem.toString());
                return mensagem;
            } catch (ClassNotFoundException e) {
                Logger.getLogger(ThreadTCP.class.getName()).log(Level.SEVERE, null, e);
            }
        } catch (IOException e) {
            Logger.getLogger(ThreadTCP.class.getName()).log(Level.SEVERE, null, e);

        }
        return null;
    }

    public void output(Object msg) throws IOException {
        out.flush();
        out.write(serializarMensagens(msg));
        out.reset();
    }

    

    private void sair() throws IOException {
        System.out.println("tentou sair");
        in.close();
        out.close();
        cliente.close();
        System.out.println("CLIENTE DESCONECTOU");
    }

    public byte[] serializarMensagens(Object mensagem) {
        ByteArrayOutputStream by = new ByteArrayOutputStream();
        try {
            ObjectOutput saida = new ObjectOutputStream(by);
            saida.writeObject(mensagem);
            saida.flush();
            return by.toByteArray();
        } catch (IOException ex) {
            Logger.getLogger(ThreadTCP.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

    public Object desserializarMensagem(byte[] data) throws IOException, ClassNotFoundException {
        ByteArrayInputStream mensagem = new ByteArrayInputStream(data);

        ObjectInput leitor = new ObjectInputStream(mensagem);
        return (Object) leitor.readObject();

    }
}
